function air_quality_gui()
% AIR_QUALITY_GUI Launch a simple real-time air quality visualizer using OpenAQ
%
% GUI features:
% - Left: listbox of available locations (user can paste a list or load from OpenAQ)
% - Center: uiaxes that plots time series of selected parameter(s)
% - Right: controls for parameters (PM2.5, PM10, CO), refresh interval, Start/Stop

% Build UI
fig = uifigure('Name','Real-Time Air Quality Visualizer','Position',[100 100 1100 600]);

% Left panel: sensor list
leftPanel = uipanel(fig,'Title','Sensors / Locations','Position',[10 10 250 580]);
lbl = uilabel(leftPanel,'Text','Sensor Location IDs or names (one per line):','Position',[10 540 230 20]);
txtSensors = uitextarea(leftPanel,'Position',[10 240 230 300],'Tooltip','Enter location names or numeric location IDs, one per line');
btnLoadExample = uibutton(leftPanel,'Text','Load Example (city: Delhi, London, Los Angeles)','Position',[10 200 230 30],...
    'ButtonPushedFcn',@(s,e) set(txtSensors,'Value',{'Delhi-US Embassy','Los Angeles - North Main Street','London Westminster'}));

btnDiscover = uibutton(leftPanel,'Text','Discover Nearby (lat,lon,dist km)','Position',[10 160 230 30],...
    'ButtonPushedFcn',@(s,e) discover_locations_callback(txtSensors));

% Center: plot area
centerPanel = uipanel(fig,'Title','Visualization','Position',[270 10 640 580]);
ax = uiaxes(centerPanel,'Position',[10 10 620 540],'NextPlot','add');
xlabel(ax,'Time (UTC)');
ylabel(ax,'Value');
grid(ax,'on');
legend(ax,'show');

% Right: controls
rightPanel = uipanel(fig,'Title','Controls','Position',[920 10 160 580]);
lblParam = uilabel(rightPanel,'Text','Choose parameters:','Position',[10 520 140 20]);
cbPM25 = uicheckbox(rightPanel,'Text','PM2.5 (pm25)','Position',[10 490 140 20],'Value',true);
cbPM10 = uicheckbox(rightPanel,'Text','PM10 (pm10)','Position',[10 460 140 20],'Value',true);
cbCO   = uicheckbox(rightPanel,'Text','CO (co)','Position',[10 430 140 20],'Value',false);

lblInterval = uilabel(rightPanel,'Text','Refresh interval (sec):','Position',[10 390 140 20]);
spInterval = uispinner(rightPanel,'Limits',[1 3600],'Value',5,'Position',[10 360 140 30]);

btnStart = uibutton(rightPanel,'Text','Start','Position',[10 300 140 40],'ButtonPushedFcn',@(s,e) start_callback());
btnStop  = uibutton(rightPanel,'Text','Stop','Position',[10 250 140 40],'Enable','off','ButtonPushedFcn',@(s,e) stop_callback());

lblStatus = uilabel(rightPanel,'Text','Status: Idle','Position',[10 200 140 40],'WordWrap','on');

% Shared variables in nested funcs
t = [];
currentPlots = containers.Map; % map parameter->line handle
history = containers.Map;      % map sensor->table of time/value per parameter

% nested functions
    function discover_locations_callback(txtArea)
        % Ask user for lat, lon, radius and call OpenAQ locations endpoint
        prompt = {'Latitude (deg):','Longitude (deg):','Radius km (max 500):'};
        dlg = inputdlg(prompt,'Discover locations',1,{'14.5995','120.9842','10'});
        if isempty(dlg), return; end
        lat = dlg{1}; lon = dlg{2}; radius = dlg{3};
        % Query OpenAQ /locations?coordinates=lat,lon&radius=... (radius meters)
        try
            url = sprintf('https://api.openaq.org/v2/locations?coordinates=%s,%s&radius=%s&limit=50',lat,lon,num2str(str2double(radius)*1000));
            opts = weboptions('Timeout',10,'ContentType','json');
            resp = webread(url,opts);
            names = {};
            for ii=1:length(resp.results)
                names{end+1} = resp.results(ii).name; %#ok<AGROW>
            end
            if isempty(names)
                uialert(fig,'No nearby locations found. Try larger radius or different coords.','No results');
            else
                txtArea.Value = names';
            end
        catch ME
            uialert(fig,["Discovery failed: " ME.message],'Error');
        end
    end

    function start_callback()
        % parse sensors list
        sensors = txtSensors.Value;
        if isempty(sensors) || all(cellfun(@(c) isempty(strtrim(c)), sensors))
            uialert(fig,'Please provide at least one sensor location name or id in the left box.','Input required');
            return;
        end
        % determine parameters
        params = {};
        if cbPM25.Value, params{end+1} = 'pm25'; end
        if cbPM10.Value, params{end+1} = 'pm10'; end
        if cbCO.Value,   params{end+1} = 'co'; end
        if isempty(params)
            uialert(fig,'Select at least one parameter to plot.','Input required');
            return;
        end

        btnStart.Enable = 'off';
        btnStop.Enable = 'on';
        lblStatus.Text = 'Status: Running...';
        % initialize history
        history = containers.Map;
        currentPlots = containers.Map;
        cla(ax);
        legend(ax,'off');

        % create timer
        interval = double(spInterval.Value);
        t = timer('ExecutionMode','fixedSpacing','Period',interval,'TimerFcn',@(~,~) timer_tick(sensors,params));
        start(t);
        % immediate first fetch
        timer_tick(sensors,params);
    end

    function stop_callback()
        if ~isempty(t) && isvalid(t)
            stop(t); delete(t);
        end
        t = [];
        btnStart.Enable = 'on';
        btnStop.Enable = 'off';
        lblStatus.Text = 'Status: Stopped';
    end

    function timer_tick(sensors, params)
        % Called by timer: fetch new measurements and update plot
        try
            for si=1:numel(sensors)
                sname = strtrim(sensors{si});
                if isempty(sname), continue; end
                % fetch for this location
                try
                    d = fetch_openaq_measurements(sname, params);
                catch
                    d = [];
                end
                if isempty(d), continue; end
                % d may contain one entry; process all measurements
                for di=1:numel(d)
                    loc = d(di).location;
                    ts = datetime('now','TimeZone','UTC');
                    key = loc; % use location name as key
                    if ~isKey(history,key)
                        history(key) = table([],[],[],'VariableNames',{'time','parameter','value'});
                    end
                    T = history(key);
                    % Append measurements
                    for m=1:numel(d(di).measurements)
                        param = d(di).measurements(m).parameter;
                        val = d(di).measurements(m).value;
                        T = [T; {datetime(d(di).measurements(m).date_utc,'InputFormat','yyyy-MM-dd''T''HH:mm:ss''Z''','TimeZone','UTC'), param, val}]; %#ok<AGROW>
                    end
                    % Keep last N points
                    if height(T) > 500
                        T = T(end-500+1:end,:);
                    end
                    history(key) = T;
                end
            end

            % Update plots: for each location+parameter, create or update
            cla(ax);
            legend(ax,'off');
            keys = history.keys;
            colors = lines(numel(keys)); % default color set
            plotHandles = [];
            labels = {};
            for kidx=1:numel(keys)
                key = keys{kidx};
                T = history(key);
                for pidx=1:numel(params)
                    p = params{pidx};
                    rows = strcmp(T.parameter,p);
                    if any(rows)
                        times = T.time(rows);
                        vals = T.value(rows);
                        h = plot(ax,times,vals,'-o','DisplayName',sprintf('%s — %s',key,p)); %#ok<NASGU>
                        plotHandles = [plotHandles h]; %#ok<AGROW>
                        labels{end+1} = sprintf('%s — %s',key,p); %#ok<AGROW>
                    end
                end
            end
            if ~isempty(plotHandles)
                legend(ax,'show','Location','best');
            end
            drawnow limitrate;
            lblStatus.Text = sprintf('Status: Last update %s UTC', datestr(datetime('now','TimeZone','UTC'),'yyyy-mm-dd HH:MM:SS'));
        catch ME
            % runtime error: show status but keep timer running
            lblStatus.Text = ['Error: ' ME.message];
        end
    end

% cleanup on close
fig.CloseRequestFcn = @(src,evt) on_close();

    function on_close()
        if ~isempty(t) && isvalid(t)
            stop(t); delete(t);
        end
        delete(fig);
    end

end
