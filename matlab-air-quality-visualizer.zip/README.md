# Real-Time Air Quality Data Visualizer (MATLAB)

This project is a MATLAB GUI tool that fetches real-time air quality data from the OpenAQ public API and visualizes selected parameters (PM2.5, PM10, CO) for multiple sensors/locations.

## Features
- Connects to OpenAQ REST API (no API key required).
- Visualize PM2.5, PM10, CO time series for multiple sensors.
- Auto-refresh (configurable interval, default 5 seconds).
- Discover nearby OpenAQ locations by coordinates.
- Easy to extend (add more parameters, smoothing, alerts).

## Files
- `fetch_openaq_measurements.m` — fetches measurements from OpenAQ.
- `air_quality_gui.m` — launches the GUI.
- `README.md` — this file.

## Requirements
- MATLAB R2018b or later recommended (uses `uifigure`).
- Internet connection to reach `https://api.openaq.org/`.

## Running
1. Put `fetch_openaq_measurements.m` and `air_quality_gui.m` in the same folder.
2. Open MATLAB, set the Current Folder to that folder.
3. Type `air_quality_gui` and press Enter.
4. Paste sensor names or location IDs into the left panel or use "Discover Nearby".
5. Select parameters and click **Start**.

## Notes on data sources
- OpenAQ aggregates measurements worldwide (PM2.5, PM10, O3, NO2, CO, etc.). Not all locations provide CO2. If you need CO2 specifically, consider alternative sources or local sensors.

## Example offline dataset (for testing without internet)
- You can use Kaggle datasets such as "Air Quality Data Set" or "Comprehensive Air Quality Dataset" to load historical data and test plotting.

## How to publish to GitHub
1. Initialize git, create a repo, and push:
   ```bash
   git init
   git add fetch_openaq_measurements.m air_quality_gui.m README.md
   git commit -m "Initial commit: MATLAB OpenAQ real-time visualizer"
   git branch -M main
   # create an empty repo on GitHub, then:
   git remote add origin https://github.com/<yourusername>/matlab-air-quality-visualizer.git
   git push -u origin main
   ```
2. Replace `<yourusername>` and repo name accordingly.

## Extending this project
- Add smoothing filters / rolling averages.
- Add AQI conversion (country-specific AQI formulas).
- Add alerts when thresholds exceeded (email/SMS).
- Add map view using `geoscatter` or MATLAB Mapping Toolbox.

## License
MIT (or choose your preferred license).
