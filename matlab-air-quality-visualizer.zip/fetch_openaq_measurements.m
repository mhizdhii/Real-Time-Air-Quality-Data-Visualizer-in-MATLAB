function data = fetch_openaq_measurements(location_id, parameters)
% FETCH_OPENAQ_MEASUREMENTS Fetch latest measurements from OpenAQ API
%   data = fetch_openaq_measurements(location_id)
%   data = fetch_openaq_measurements(location_id, parameters)
%
%   location_id : string or numeric id (OpenAQ location id). You can pass a
%                 vector of ids or a single id.
%   parameters  : cell array of strings like {'pm25','pm10','co'} (optional)
%
%   Returns a struct array with fields:
%     .location, .city, .country, .coordinates (lat/lon), .measurements
%     where .measurements is a struct array of parameter/time/value/unit.

if nargin < 2
    parameters = {};
end

base = "https://api.openaq.org/v2/measurements";

% ensure vector of ids
if ~iscell(location_id)
    if isnumeric(location_id)
        locs = num2cell(location_id);
    elseif ischar(location_id) || isstring(location_id)
        locs = {char(location_id)};
    else
        locs = location_id;
    end
else
    locs = location_id;
end

opts = weboptions('Timeout', 10, 'ContentType', 'json');

data = struct('location', {}, 'city', {}, 'country', {}, 'coordinates', {}, 'measurements', {});
for i=1:numel(locs)
    loc = locs{i};
    % build query: get latest measurements for location
    % filter by parameter if provided
    query = strcat("?limit=100&page=1&offset=0&sort=desc&order_by=datetime");
    if ~isempty(parameters)
        % parameters are comma separated
        qparams = join(parameters,',');
        query = query + "&parameter=" + char(qparams);
    end

    % If loc looks numeric, use location_id param, else use city or location query:
    if all(isstrprop(char(loc),'digit'))
        url = base + query + "&location_id=" + string(loc);
    else
        % try to use location name
        url = base + query + "&location=" + urlencode(char(loc));
    end

    try
        resp = webread(char(url), opts);
    catch ME
        warning("Failed to fetch OpenAQ data for %s: %s", char(loc), ME.message);
        continue
    end

    if isfield(resp,'results') && ~isempty(resp.results)
        % Group measurements by location + coordinates + city
        % We'll collect into one struct per unique location
        res = resp.results;
        % Basic metadata from first entry
        first = res(1);
        s.location = first.location;
        s.city = first.city;
        s.country = first.country;
        if isfield(first,'coordinates')
            s.coordinates = first.coordinates;
        else
            s.coordinates = struct('latitude',NaN,'longitude',NaN);
        end
        % Make measurements struct array
        meas = struct('parameter', {}, 'value', {}, 'unit', {}, 'date_utc', {});
        for k=1:length(res)
            r = res(k);
            m.parameter = r.parameter;
            m.value = r.value;
            if isfield(r,'unit'), m.unit = r.unit; else m.unit = ""; end
            if isfield(r,'date') && isfield(r.date,'utc')
                m.date_utc = r.date.utc;
            else
                m.date_utc = "";
            end
            meas(end+1) = m; %#ok<AGROW>
        end
        s.measurements = meas;
        data(end+1) = s; %#ok<AGROW>
    else
        % no results
        warning("OpenAQ returned no results for query %s", char(url));
    end
end

end
